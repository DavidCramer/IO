=== IO ===
Contributors: Desertsnowman
Donate link: http://cramer.co.za
Tags:
Requires at least: 3.9
Tested up to: 4.4
Stable tag: 0.0.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Create Data Management Structures

== Description ==

Create Data Management Structures

== Installation ==

Install the plugin through the WordPress Plugins Installer or upload `plugin-name.php` to the plugins directory of your content directory
1. Activate the plugin through the 'Plugins' menu in WordPress

== Frequently Asked Questions ==

= Does It Got To Eleven? =

Of course it does.

== Screenshots ==

1. Screenshot 1 description
2. Screenshot 2 description

== Changelog ==

= 0.1.0 =
Initial Version

== Upgrade Notice ==
Nothing to report
